#Responsive Blog

Source files of a Responsive Blog built using [Responsive.gs](http://responsive.gs/). Steps are covered in detail in Responsive Web Design by Example, Second Edition.

