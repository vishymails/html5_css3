##Responsive Website for Startup

A demo and source code of responsive website from Responsive Web Design by Examples, Second Edition, **Chapter 7 and 8**.

###Dependencies
  
* [Foundation](http://foundation.zurb.com/) by Zurb
* [Foundation Icons](https://github.com/zurb/foundation-icons) by Zurb
* [Bourbon](http://bourbon.io/), a Sass Mixins library

####Installing dependencies
Install the dependencies all at once through Bower using this following command:
`bower install`

